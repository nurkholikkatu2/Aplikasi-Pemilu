﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class StaticClass {
    public static string CrossSceneInformation { get; set; }
}
