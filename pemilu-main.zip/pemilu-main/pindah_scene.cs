﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class pindah_scene : MonoBehaviour
{
    public InputField total_suara;
    public int suara_Calon;
    public void kirim()
    {
        suara_Calon = int.Parse(total_suara.text);
        StaticClass.CrossSceneInformation = suara_Calon.ToString();
        SceneManager.LoadScene("DM");
    }
}
