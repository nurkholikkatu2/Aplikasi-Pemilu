﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static System.Math;
using UnityEngine.SceneManagement;   

public class DM : MonoBehaviour
{
    public int calon1 = 0;
    public int calon2 = 0;
    public int calon3 = 0;
    public int suaraMasuk = 0;
    public int suaraBatal = 0;
    public int totalSuara;
    public float barMerah = 0;
    public float barBiru = 0;
    public float barHijau = 0;
    public int persen = 100;
    public Text calon_01;
    public Text calon_02;
    public Text calon_03;
    public Text masuk;
    public Text batal;
    public Text total;
    public Text bar01;
    public Text bar02;
    public Text bar03;
    public Slider sliderMerah;
    public Slider sliderBiru;
    public Slider sliderHijau;
    void Update()
    {
    //Pindah Scene
        if (Input.GetKeyDown(KeyCode.T))
        {
            SceneManager.LoadScene("Main Menu");
        }
        if (Input.GetKeyDown(KeyCode.U))
        {
            SceneManager.LoadScene("DM");
        }
        if (Input.GetKeyDown(KeyCode.P))
        {
            StaticClass.CrossSceneInformation = totalSuara.ToString();
            totalSuara = int.Parse(total.text);
            SceneManager.LoadScene("BE");
        }
    //Penjumlahan
    if (suaraMasuk + suaraBatal < totalSuara)
    {
        if (Input.GetKeyDown(KeyCode.Q))
        {
            calon1++;
            suaraMasuk++;
            calon_01.text = calon1.ToString();
            masuk.text = suaraMasuk.ToString();
            PlayerPrefs.SetInt("calon1", calon1);
            PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            calon2++;
            suaraMasuk++;
            calon_02.text = calon2.ToString();
            masuk.text = suaraMasuk.ToString();
            PlayerPrefs.SetInt("calon2", calon2);
            PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
        }
        if (Input.GetKeyDown(KeyCode.E))
        {
            calon3++;
            suaraMasuk++;
            calon_03.text = calon3.ToString();
            masuk.text = suaraMasuk.ToString();
            PlayerPrefs.SetInt("calon3", calon3);
            PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
        }
        //Suara Batal
        if (Input.GetKeyDown(KeyCode.Z))
        {
            suaraBatal++;
            batal.text = suaraBatal.ToString();
            PlayerPrefs.SetInt("suaraBatal", suaraBatal);
        }
    }
    //Pengurangan
        if (calon1 > 0)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                calon1--;
                suaraMasuk--;
                calon_01.text = calon1.ToString();
                masuk.text = suaraMasuk.ToString();
                PlayerPrefs.SetInt("calon1", calon1);
                PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
            }
        }
        if (calon2 > 0)
        {
            if (Input.GetKeyDown(KeyCode.S))
            {
                calon2--;
                suaraMasuk--;
                calon_02.text = calon2.ToString();
                masuk.text = suaraMasuk.ToString();
                PlayerPrefs.SetInt("calon2", calon2);
                PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
            }
        }
        if (calon3 > 0)
        {
            if (Input.GetKeyDown(KeyCode.D))
            {
                calon3--;
                suaraMasuk--;
                calon_03.text = calon3.ToString();
                masuk.text = suaraMasuk.ToString();
                PlayerPrefs.SetInt("calon3", calon3);
                PlayerPrefs.SetInt("suaraMasuk", suaraMasuk);
            }
        }
        if (suaraBatal > 0)
        {
            if (Input.GetKeyDown(KeyCode.X))
            {
                suaraBatal--;
                batal.text = suaraBatal.ToString();
                PlayerPrefs.SetInt("suaraBatal", suaraBatal);
            }
        }
        //Nilai persen
        if (suaraMasuk == 0)
        {
            bar01.text = "0%";
            bar02.text = "0%";
            bar03.text = "0%";
        }
        else
        {
            bar01.text = (Round((((float) calon1/suaraMasuk)*persen),2)).ToString() + "%";
            bar02.text = (Round((((float) calon2/suaraMasuk)*persen),2)).ToString() + "%";
            bar03.text = (Round((((float) calon3/suaraMasuk)*persen),2)).ToString() + "%";
        }
        //Progress Bar
        if (suaraMasuk == 0)
        {
            sliderMerah.value = 0;
            sliderBiru.value = 0;
            sliderHijau.value = 0;
        }
        else
        {
            sliderMerah.value = (float) calon1/suaraMasuk;
            sliderBiru.value = (float) calon2/suaraMasuk;
            sliderHijau.value = (float) calon3/suaraMasuk;
        }
        //Delete
        if (Input.GetKeyDown(KeyCode.M))
        {
            PlayerPrefs.DeleteAll();
        }
    }
    void Start()
    {
    //Progress Bar
        //Maximum value
        sliderMerah.maxValue = 1;
        sliderBiru.maxValue = 1;
        sliderHijau.maxValue = 1;
        //Minimum Value
        sliderMerah.minValue = 0;
        sliderBiru.minValue = 0;
        sliderHijau.minValue = 0;

        //Return Value \
        calon_01.text = PlayerPrefs.GetInt("calon1").ToString();
        calon1 = PlayerPrefs.GetInt("calon1");
        calon_02.text = PlayerPrefs.GetInt("calon2").ToString();
        calon2 = PlayerPrefs.GetInt("calon2");
        calon_03.text = PlayerPrefs.GetInt("calon3").ToString();
        calon3 = PlayerPrefs.GetInt("calon3");
        masuk.text = PlayerPrefs.GetInt("suaraMasuk").ToString();
        suaraMasuk = PlayerPrefs.GetInt("suaraMasuk");
        batal.text = PlayerPrefs.GetInt("suaraBatal").ToString();
        suaraBatal = PlayerPrefs.GetInt("suaraBatal");
        //Total Suara
        total.text = StaticClass.CrossSceneInformation.ToString();
        totalSuara = int.Parse(total.text);

    }
}
